package com.example.ai

import android.util.Log
import com.example.BuildConfig
import com.example.data.VideoProject
import com.example.data.VideoScene
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AiGeneratedScript(
    val title: String,
    val viralHook: String,
    val viralTitle: String,
    val hashtags: String,
    val scenes: List<VideoScene>
)

class GeminiVideoService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generateShortsScript(
        topic: String,
        niche: String,
        targetDurationSec: Int = 20,
        voiceStyle: String = "Energetic",
        visualStyle: String = "Cyberpunk"
    ): AiGeneratedScript = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            Log.d("GeminiVideoService", "Using built-in creative generator (API key placeholder)")
            return@withContext generateCreativeFallback(topic, niche, targetDurationSec, visualStyle)
        }

        val prompt = """
You are an elite viral TikTok and YouTube Shorts content creator and AI director.
Create a high-retention vertical short-form video script about:
Topic: "$topic"
Niche: "$niche"
Duration: $targetDurationSec seconds (approx 3-5 scenes of 3-5 seconds each)
Visual Theme: $visualStyle

You MUST respond strictly with a valid JSON object matching this schema:
{
  "title": "Short title",
  "viralTitle": "Catchy YouTube Shorts / TikTok title with emoji (under 60 chars)",
  "viralHook": "Extreme curiosity or pattern-interrupt hook (First 3 seconds)",
  "hashtags": "#Shorts #TikTok #FYP #Trending #TopicSpecific",
  "scenes": [
    {
      "sceneIndex": 1,
      "voiceoverText": "Exact words narrator speaks for this scene (punchy, fast)",
      "captionOverlay": "3-5 key UPPERCASE words to flash on screen",
      "visualPrompt": "Detailed cinematic AI visual prompt suitable for Veo / Midjourney, vertical 9:16 shot",
      "visualTheme": "$visualStyle",
      "durationSeconds": 4,
      "transition": "Flash Cut",
      "soundEffect": "Sub Drop"
    }
  ]
}
Transitions can be: "Flash Cut", "Zoom In", "Slide Left", "Glitch", "Fade".
SoundEffects can be: "Sub Drop", "Whoosh", "Ding", "Camera Click", "Pop".
Do not output markdown code blocks if possible, just the raw JSON object.
""".trimIndent()

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val jsonBody = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        }
                        put("parts", partsArray)
                    }
                    put(contentObj)
                }
                put("contents", contentsArray)

                val genConfig = JSONObject().apply {
                    put("temperature", 0.7)
                    val responseFormat = JSONObject().apply {
                        put("mimeType", "application/json")
                    }
                    put("responseMimeType", "application/json")
                }
                put("generationConfig", genConfig)
            }

            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                Log.w("GeminiVideoService", "API call returned code ${response.code}: ${response.message}")
                return@withContext generateCreativeFallback(topic, niche, targetDurationSec, visualStyle)
            }

            val responseBody = response.body?.string() ?: ""
            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val rawText = parts?.optJSONObject(0)?.optString("text", "") ?: ""

            parseAiScript(rawText, topic, visualStyle)
        } catch (e: Exception) {
            Log.e("GeminiVideoService", "Gemini call failed, falling back to smart generator", e)
            generateCreativeFallback(topic, niche, targetDurationSec, visualStyle)
        }
    }

    private fun parseAiScript(rawJson: String, topic: String, defaultVisual: String): AiGeneratedScript {
        var cleanJson = rawJson.trim()
        if (cleanJson.startsWith("```json")) {
            cleanJson = cleanJson.removePrefix("```json").trim()
        }
        if (cleanJson.startsWith("```")) {
            cleanJson = cleanJson.removePrefix("```").trim()
        }
        if (cleanJson.endsWith("```")) {
            cleanJson = cleanJson.removeSuffix("```").trim()
        }

        val obj = JSONObject(cleanJson)
        val title = obj.optString("title", topic)
        val viralTitle = obj.optString("viralTitle", "$topic 🚀")
        val viralHook = obj.optString("viralHook", "Wait until you see this...")
        val hashtags = obj.optString("hashtags", "#Shorts #TikTok #Viral #AI")

        val scenesJsonArray = obj.optJSONArray("scenes") ?: JSONArray()
        val scenes = mutableListOf<VideoScene>()

        for (i in 0 until scenesJsonArray.length()) {
            val sceneObj = scenesJsonArray.getJSONObject(i)
            scenes.add(
                VideoScene(
                    id = "ai_scene_${i + 1}",
                    sceneIndex = sceneObj.optInt("sceneIndex", i + 1),
                    visualPrompt = sceneObj.optString("visualPrompt", "Cinematic vertical 9:16 shot of $topic"),
                    visualTheme = sceneObj.optString("visualTheme", defaultVisual),
                    voiceoverText = sceneObj.optString("voiceoverText", "Check this out."),
                    captionOverlay = sceneObj.optString("captionOverlay", "MIND BLOWING!"),
                    durationSeconds = sceneObj.optInt("durationSeconds", 4).coerceIn(2, 10),
                    transition = sceneObj.optString("transition", "Zoom In"),
                    soundEffect = sceneObj.optString("soundEffect", "Whoosh")
                )
            )
        }

        if (scenes.isEmpty()) {
            return generateCreativeFallback(topic, "AI Generation", 16, defaultVisual)
        }

        return AiGeneratedScript(title, viralHook, viralTitle, hashtags, scenes)
    }

    fun generateCreativeFallback(
        topic: String,
        niche: String,
        targetDurationSec: Int,
        visualStyle: String
    ): AiGeneratedScript {
        val cleanTopic = if (topic.isBlank()) "Secret Productivity Technique" else topic.trim()
        val scenes = listOf(
            VideoScene(
                id = "scene_fb_1",
                sceneIndex = 1,
                visualPrompt = "Cinematic 9:16 vertical shot, ultra realistic lighting, dramatic angle of $cleanTopic with electric neon ambient glow",
                visualTheme = visualStyle,
                voiceoverText = "Most people will never learn this truth about $cleanTopic until it's too late.",
                captionOverlay = "NEVER DO THIS!",
                durationSeconds = 4,
                transition = "Flash Cut",
                soundEffect = "Sub Drop"
            ),
            VideoScene(
                id = "scene_fb_2",
                sceneIndex = 2,
                visualPrompt = "Close-up holographic interface displaying detailed analysis and glowing data streams of $cleanTopic",
                visualTheme = visualStyle,
                voiceoverText = "Step one: eliminate the friction by breaking it down into thirty second micro-habits.",
                captionOverlay = "THE 30-SECOND RULE",
                durationSeconds = 4,
                transition = "Zoom In",
                soundEffect = "Whoosh"
            ),
            VideoScene(
                id = "scene_fb_3",
                sceneIndex = 3,
                visualPrompt = "Dramatic visual shift with glowing particle physics and high-speed motion blur highlighting breakthrough",
                visualTheme = visualStyle,
                voiceoverText = "Within forty-eight hours, your focus and results will surpass ninety-five percent of your competition.",
                captionOverlay = "TOP 1% RESULTS!",
                durationSeconds = 4,
                transition = "Glitch",
                soundEffect = "Ding"
            ),
            VideoScene(
                id = "scene_fb_4",
                sceneIndex = 4,
                visualPrompt = "Epic vertical cinematic reveal shot with warm sunset lighting and lens flare in modern studio",
                visualTheme = visualStyle,
                voiceoverText = "Save this video right now, and follow for more daily creator game plans.",
                captionOverlay = "SAVE & FOLLOW!",
                durationSeconds = 4,
                transition = "Zoom In",
                soundEffect = "Camera Click"
            )
        )

        return AiGeneratedScript(
            title = cleanTopic,
            viralHook = "Most people will never learn this truth about $cleanTopic until it's too late.",
            viralTitle = "The Truth About $cleanTopic Nobody Tells You ⚡",
            hashtags = "#$cleanTopic #Shorts #TikTokViral #CreatorTips #FYP".replace(" ", ""),
            scenes = scenes
        )
    }
}
