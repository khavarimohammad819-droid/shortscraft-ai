package com.example.data

object DefaultProjects {
    val niches = listOf(
        NicheOption(
            id = "tech_ai",
            name = "Tech & AI Secrets",
            emoji = "⚡",
            defaultPrompt = "3 mind-blowing AI breakthroughs that feel completely unreal in 2026",
            suggestedHooks = listOf(
                "Stop scrolling if you use artificial intelligence every day.",
                "Bookmark this video immediately before big tech removes it.",
                "Here are 3 secret AI tools that honestly feel illegal to know."
            )
        ),
        NicheOption(
            id = "mystery_space",
            name = "Cosmic & Deep Mysteries",
            emoji = "🌌",
            defaultPrompt = "Terrifying mysteries discovered at the edge of the known universe",
            suggestedHooks = listOf(
                "You won't sleep tonight after finding out what NASA heard in deep space.",
                "Scientists just detected a signal from 10 billion light-years away.",
                "There is a cosmic void so empty that physics completely breaks down."
            )
        ),
        NicheOption(
            id = "dopamine_mind",
            name = "Psychology & Lifehacks",
            emoji = "🧠",
            defaultPrompt = "The 2-minute psychological trick to instantly kill procrastination",
            suggestedHooks = listOf(
                "Your brain is secretly addicted to cheap dopamine loops.",
                "Try this 2-minute rule right now and watch your focus 10x.",
                "Why 99% of people fail their goals before 10 AM."
            )
        ),
        NicheOption(
            id = "ancient_history",
            name = "Ancient History Lore",
            emoji = "🗿",
            defaultPrompt = "Unexplained discoveries inside ancient underground pyramids",
            suggestedHooks = listOf(
                "Historians refuse to talk about what was buried under the desert.",
                "An ancient map from 3,000 years ago shows continents that didn't exist.",
                "This lost underground city had technology we still can't explain."
            )
        )
    )

    val captionStyles = listOf(
        CaptionStyle(
            id = "mrbeast",
            name = "MrBeast Pop",
            primaryColorHex = 0xFFFFFFFF,
            highlightColorHex = 0xFFFFE500,
            backgroundColorHex = 0xD9000000,
            isUppercase = true,
            hasGlow = true,
            fontSizeSp = 24
        ),
        CaptionStyle(
            id = "neon_cyan",
            name = "Cyber Cyan",
            primaryColorHex = 0xFFFFFFFF,
            highlightColorHex = 0xFF25F4EE,
            backgroundColorHex = 0xD90A0E1A,
            isUppercase = true,
            hasGlow = true,
            fontSizeSp = 23
        ),
        CaptionStyle(
            id = "cherry_pink",
            name = "TikTok Viral",
            primaryColorHex = 0xFFFFFFFF,
            highlightColorHex = 0xFFFE2C55,
            backgroundColorHex = 0xD9140508,
            isUppercase = true,
            hasGlow = true,
            fontSizeSp = 24
        ),
        CaptionStyle(
            id = "clean_minimal",
            name = "Clean Minimal",
            primaryColorHex = 0xFFFFFFFF,
            highlightColorHex = 0xFF00E676,
            backgroundColorHex = 0x88000000,
            isUppercase = false,
            hasGlow = false,
            fontSizeSp = 20
        )
    )

    val voicePersonas = listOf(
        VoicePersona(
            id = "alex",
            name = "Alex (Hyped Creator)",
            subtitle = "Fast-paced, energetic viral Shorts pacing",
            pitch = 1.05f,
            speechRate = 1.25f
        ),
        VoicePersona(
            id = "marcus",
            name = "Marcus (Deep Mystery)",
            subtitle = "Low pitch, dramatic pause, documentary tone",
            pitch = 0.85f,
            speechRate = 1.05f
        ),
        VoicePersona(
            id = "elena",
            name = "Elena (Tech & Precision)",
            subtitle = "Crystal clear, modern studio presentation",
            pitch = 1.0f,
            speechRate = 1.15f
        ),
        VoicePersona(
            id = "nova",
            name = "Nova (Futuristic AI)",
            subtitle = "Robotic resonance, sci-fi cyber vibe",
            pitch = 1.15f,
            speechRate = 1.2f
        )
    )

    val musicTracks = listOf(
        MusicTrack("phonk", "Phonk Energy (Viral)", 140, "Aggressive high retention bass"),
        MusicTrack("space_synth", "Deep Cosmic Synth", 110, "Mysterious ethereal atmosphere"),
        MusicTrack("lofi_chill", "Midnight Lo-Fi Chill", 85, "Smooth storytelling ambient"),
        MusicTrack("epic_trailer", "Cinematic Trailer Drop", 125, "Dramatic brass & ticking suspense"),
        MusicTrack("none", "No Music (Voice Only)", 0, "Clean dialog")
    )

    fun getInitialProjects(): List<VideoProject> {
        val spaceScenes = listOf(
            VideoScene(
                id = "sp_1",
                sceneIndex = 1,
                visualPrompt = "Cinematic vertical shot of deep galaxy void with supermassive black hole horizon, glowing purple accretion disk",
                visualTheme = "Deep Space",
                voiceoverText = "If you think the ocean is terrifying, wait until you hear what lurks in deep space.",
                captionOverlay = "WHAT LURKS IN DEEP SPACE?",
                durationSeconds = 4,
                transition = "Flash Cut",
                soundEffect = "Sub Drop"
            ),
            VideoScene(
                id = "sp_2",
                sceneIndex = 2,
                visualPrompt = "Glowing nebula cloud with rogue wandering planet adrift in pitch black cosmic vacuum",
                visualTheme = "Deep Space",
                voiceoverText = "There are over two hundred billion rogue planets drifting in pitch black darkness with no sun.",
                captionOverlay = "200 BILLION ROGUE PLANETS!",
                durationSeconds = 4,
                transition = "Zoom In",
                soundEffect = "Whoosh"
            ),
            VideoScene(
                id = "sp_3",
                sceneIndex = 3,
                visualPrompt = "Futuristic telescope observatory detecting radio wave pulses from distant pulsar star",
                visualTheme = "Cyberpunk",
                voiceoverText = "Astronomers picked up an unexplained repeating signal repeating precisely every eighteen minutes.",
                captionOverlay = "REPEATING EVERY 18 MINUTES!",
                durationSeconds = 4,
                transition = "Slide Left",
                soundEffect = "Ding"
            ),
            VideoScene(
                id = "sp_4",
                sceneIndex = 4,
                visualPrompt = "Spacecraft looking down at planetary vortex with cosmic aurora borealis",
                visualTheme = "Deep Space",
                voiceoverText = "Follow for part two before this signal disappears into the cosmic void forever.",
                captionOverlay = "FOLLOW FOR PART 2!",
                durationSeconds = 4,
                transition = "Zoom In",
                soundEffect = "Whoosh"
            )
        )

        val dopamineScenes = listOf(
            VideoScene(
                id = "dp_1",
                sceneIndex = 1,
                visualPrompt = "Neon cyberpunk silhouette looking at glowing holographic phone screen with digital rain reflection",
                visualTheme = "Cyberpunk",
                voiceoverText = "Stop scrolling right now. Your brain is trapped in a cheap dopamine loop.",
                captionOverlay = "STOP SCROLLING RIGHT NOW!",
                durationSeconds = 4,
                transition = "Glitch",
                soundEffect = "Sub Drop"
            ),
            VideoScene(
                id = "dp_2",
                sceneIndex = 2,
                visualPrompt = "Futuristic digital clock countdown timer glowing bright yellow on metallic desk",
                visualTheme = "Cyberpunk",
                voiceoverText = "Neuroscientists call this the two-minute reset rule. All you need is sixty seconds of silence.",
                captionOverlay = "THE 2-MINUTE RESET RULE",
                durationSeconds = 4,
                transition = "Zoom In",
                soundEffect = "Whoosh"
            ),
            VideoScene(
                id = "dp_3",
                sceneIndex = 3,
                visualPrompt = "Human brain hologram glowing with neural synapses firing in electric cyan lightning",
                visualTheme = "Deep Space",
                voiceoverText = "Put your screen facedown, close your eyes, and let your baseline neurochemistry stabilize.",
                captionOverlay = "RECHARGE YOUR FOCUS",
                durationSeconds = 4,
                transition = "Fade",
                soundEffect = "Ding"
            ),
            VideoScene(
                id = "dp_4",
                sceneIndex = 4,
                visualPrompt = "Cinematic sunrise over cyberpunk futuristic high tech metropolis with lens flare",
                visualTheme = "Cyberpunk",
                voiceoverText = "Double tap if you needed this reminder today, and save this video for later.",
                captionOverlay = "SAVE THIS FOR LATER!",
                durationSeconds = 4,
                transition = "Zoom In",
                soundEffect = "Camera Click"
            )
        )

        val ancientScenes = listOf(
            VideoScene(
                id = "anc_1",
                sceneIndex = 1,
                visualPrompt = "Mysterious subterranean cavern illuminated by ancient golden relic with glowing runes",
                visualTheme = "Ancient Mystery",
                voiceoverText = "Archaeologists just found an underground vault buried three hundred feet below the desert.",
                captionOverlay = "300 FEET BENEATH THE DESERT!",
                durationSeconds = 4,
                transition = "Flash Cut",
                soundEffect = "Sub Drop"
            ),
            VideoScene(
                id = "anc_2",
                sceneIndex = 2,
                visualPrompt = "Stone doorway with carved astronomical constellations and glowing crystal keyhole",
                visualTheme = "Ancient Mystery",
                voiceoverText = "Inside was a massive stone door carved with star charts matching modern satellite coordinates.",
                captionOverlay = "STAR CHARTS MATCHING SATELLITES!",
                durationSeconds = 4,
                transition = "Zoom In",
                soundEffect = "Whoosh"
            ),
            VideoScene(
                id = "anc_3",
                sceneIndex = 3,
                visualPrompt = "Ancient artifact floating above pedestal surrounded by dust motes and sunlight rays",
                visualTheme = "Ancient Mystery",
                voiceoverText = "Carbon dating tests showed the stone door is at least twelve thousand years older than civilization.",
                captionOverlay = "12,000 YEARS OLDER!",
                durationSeconds = 4,
                transition = "Slide Left",
                soundEffect = "Ding"
            )
        )

        return listOf(
            VideoProject(
                id = 1,
                title = "Dark Space Mysteries",
                topic = "5 Terrifying Facts About Deep Space",
                niche = "Cosmic & Deep Mysteries",
                aspectRatio = "9:16",
                voicePersona = "Marcus (Deep Mystery)",
                captionStyle = "MrBeast Pop",
                musicTrack = "Deep Cosmic Synth",
                scenesJson = VideoProject.scenesToJson(spaceScenes),
                viralHook = "If you think the ocean is terrifying, wait until you hear what lurks in deep space.",
                viralTitle = "5 Dark Space Facts That Will Keep You Awake 🌌",
                hashtags = "#SpaceMystery #UniverseFacts #Shorts #CosmicHorror #FYP",
                totalDurationSeconds = 16,
                isFavorite = true
            ),
            VideoProject(
                id = 2,
                title = "The 2-Minute Dopamine Reset",
                topic = "How to break phone addiction & reclaim extreme focus",
                niche = "Psychology & Lifehacks",
                aspectRatio = "9:16",
                voicePersona = "Alex (Hyped Creator)",
                captionStyle = "Cyber Cyan",
                musicTrack = "Phonk Energy (Viral)",
                scenesJson = VideoProject.scenesToJson(dopamineScenes),
                viralHook = "Stop scrolling right now. Your brain is trapped in a cheap dopamine loop.",
                viralTitle = "Stop Scrolling: The 2-Minute Dopamine Reset 🧠⚡",
                hashtags = "#Productivity #DopamineDetox #Mindset #SelfImprovement #TikTokShorts",
                totalDurationSeconds = 16,
                isFavorite = true
            ),
            VideoProject(
                id = 3,
                title = "Lost Desert Vault Discovery",
                topic = "Ancient 12,000 year old vault found beneath the desert",
                niche = "Ancient History Lore",
                aspectRatio = "9:16",
                voicePersona = "Marcus (Deep Mystery)",
                captionStyle = "MrBeast Pop",
                musicTrack = "Cinematic Trailer Drop",
                scenesJson = VideoProject.scenesToJson(ancientScenes),
                viralHook = "Archaeologists just found an underground vault buried three hundred feet below the desert.",
                viralTitle = "They Found A 12,000 Year Old Vault Under The Desert 🗿",
                hashtags = "#AncientMysteries #Archaeology #HiddenHistory #Unexplained #Shorts",
                totalDurationSeconds = 12,
                isFavorite = false
            )
        )
    }
}
