package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import org.json.JSONArray
import org.json.JSONObject

@Entity(tableName = "video_projects")
data class VideoProject(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val topic: String,
    val niche: String,
    val aspectRatio: String = "9:16",
    val voicePersona: String = "Alex (Hyped Creator)",
    val captionStyle: String = "MrBeast Pop",
    val musicTrack: String = "Phonk Energy",
    val scenesJson: String = "[]",
    val viralHook: String = "",
    val viralTitle: String = "",
    val hashtags: String = "#Shorts #TikTok #Viral #AI",
    val totalDurationSeconds: Int = 20,
    val createdAt: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
) {
    fun getScenes(): List<VideoScene> {
        val list = mutableListOf<VideoScene>()
        try {
            val jsonArray = JSONArray(scenesJson)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    VideoScene(
                        id = obj.optString("id", "scene_$i"),
                        sceneIndex = obj.optInt("sceneIndex", i + 1),
                        visualPrompt = obj.optString("visualPrompt", ""),
                        visualTheme = obj.optString("visualTheme", "Cyberpunk"),
                        voiceoverText = obj.optString("voiceoverText", ""),
                        captionOverlay = obj.optString("captionOverlay", ""),
                        durationSeconds = obj.optInt("durationSeconds", 4),
                        transition = obj.optString("transition", "Zoom In"),
                        soundEffect = obj.optString("soundEffect", "Whoosh")
                    )
                )
            }
        } catch (e: Exception) {
            // fallback
        }
        return list
    }

    companion object {
        fun scenesToJson(scenes: List<VideoScene>): String {
            val array = JSONArray()
            scenes.forEach { s ->
                val obj = JSONObject().apply {
                    put("id", s.id)
                    put("sceneIndex", s.sceneIndex)
                    put("visualPrompt", s.visualPrompt)
                    put("visualTheme", s.visualTheme)
                    put("voiceoverText", s.voiceoverText)
                    put("captionOverlay", s.captionOverlay)
                    put("durationSeconds", s.durationSeconds)
                    put("transition", s.transition)
                    put("soundEffect", s.soundEffect)
                }
                array.put(obj)
            }
            return array.toString()
        }
    }
}

data class VideoScene(
    val id: String = java.util.UUID.randomUUID().toString().take(8),
    val sceneIndex: Int = 1,
    val visualPrompt: String,
    val visualTheme: String = "Cyberpunk",
    val voiceoverText: String,
    val captionOverlay: String = "",
    val durationSeconds: Int = 4,
    val transition: String = "Zoom In",
    val soundEffect: String = "Whoosh"
)

data class NicheOption(
    val id: String,
    val name: String,
    val emoji: String,
    val defaultPrompt: String,
    val suggestedHooks: List<String>
)

data class CaptionStyle(
    val id: String,
    val name: String,
    val primaryColorHex: Long = 0xFFFFFFFF,
    val highlightColorHex: Long = 0xFFFFD600,
    val backgroundColorHex: Long = 0xCC000000,
    val isUppercase: Boolean = true,
    val hasGlow: Boolean = true,
    val fontSizeSp: Int = 24
)

data class VoicePersona(
    val id: String,
    val name: String,
    val subtitle: String,
    val pitch: Float = 1.0f,
    val speechRate: Float = 1.2f
)

data class MusicTrack(
    val id: String,
    val name: String,
    val bpm: Int,
    val vibe: String
)
