package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class ProjectRepository(private val dao: ProjectDao) {
    val allProjects: Flow<List<VideoProject>> = dao.getAllProjects()

    suspend fun checkAndSeedDefaults() = withContext(Dispatchers.IO) {
        val count = dao.getCount()
        if (count == 0) {
            val defaults = DefaultProjects.getInitialProjects()
            defaults.forEach { dao.insertProject(it) }
        }
    }

    suspend fun getProjectById(id: Long): VideoProject? = withContext(Dispatchers.IO) {
        dao.getProjectById(id)
    }

    suspend fun saveProject(project: VideoProject): Long = withContext(Dispatchers.IO) {
        if (project.id == 0L) {
            dao.insertProject(project)
        } else {
            dao.updateProject(project)
            project.id
        }
    }

    suspend fun deleteProject(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteProjectById(id)
    }
}
