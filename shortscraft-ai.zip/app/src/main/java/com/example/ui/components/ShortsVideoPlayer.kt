package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.DefaultProjects
import com.example.data.VideoProject
import com.example.data.VideoScene
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.TikTokCyan
import com.example.ui.theme.TikTokPink
import com.example.ui.theme.ViralGreen
import com.example.ui.theme.ViralYellow

@Composable
fun ShortsVideoPlayer(
    project: VideoProject,
    currentSceneIndex: Int,
    sceneProgress: Float,
    isPlaying: Boolean,
    onTogglePlay: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scenes = remember(project.scenesJson) { project.getScenes() }
    val currentScene: VideoScene = scenes.getOrNull(currentSceneIndex)
        ?: scenes.firstOrNull()
        ?: VideoScene(
            visualPrompt = "Empty scene",
            voiceoverText = "Add scenes to start",
            captionOverlay = "SHORT VIDEO"
        )

    val captionStyle = remember(project.captionStyle) {
        DefaultProjects.captionStyles.find { it.name == project.captionStyle }
            ?: DefaultProjects.captionStyles.first()
    }

    // Infinite rotation for the vinyl sound disc
    val infiniteTransition = rememberInfiniteTransition(label = "disc_anim")
    val discRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "disc_spin"
    )

    // Camera pan & zoom Ken Burns calculation based on scene progress
    val scale = 1.02f + (sceneProgress * 0.12f)
    val translationY = (sceneProgress - 0.5f) * 20f

    BoxWithConstraints(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color.Black)
            .border(1.dp, StudioBorder, RoundedCornerShape(20.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onTogglePlay
            )
            .testTag("shorts_player_container"),
        contentAlignment = Alignment.Center
    ) {
        val playerRatio = 9f / 16f
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .aspectRatio(playerRatio)
                .clip(RoundedCornerShape(18.dp))
                .background(Color.Black)
        ) {
            // 1. Scene Visual Asset Background
            SceneVisualBackground(
                theme = currentScene.visualTheme,
                scale = scale,
                translationY = translationY,
                transition = currentScene.transition,
                sceneProgress = sceneProgress
            )

            // 2. Cinematic Vignette & Gradient Overlays
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = 0.55f),
                                Color.Transparent,
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.85f)
                            )
                        )
                    )
            )

            // 3. Top Bar (Audio Track & Aspect Ratio badge)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Music badge
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Black.copy(alpha = 0.55f),
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, Color.White.copy(alpha = 0.2f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = "Music",
                            tint = TikTokCyan,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = project.musicTrack,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 140.dp)
                        )
                    }
                }

                // 9:16 Shorts tag
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = TikTokPink.copy(alpha = 0.85f)
                ) {
                    Text(
                        text = "9:16 SHORTS",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }

            // 4. Center Kinetic Captions (TikTok / Shorts Subtitles)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.Center)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                KineticCaptionDisplay(
                    captionText = if (currentScene.captionOverlay.isNotBlank()) currentScene.captionOverlay else currentScene.voiceoverText,
                    sceneProgress = sceneProgress,
                    style = captionStyle
                )
            }

            // 5. Play/Pause Big Center Indicator when paused
            AnimatedVisibility(
                visible = !isPlaying,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(Color.Black.copy(alpha = 0.65f), CircleShape)
                        .border(1.5.dp, TikTokPink, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            // 6. Right-Side TikTok Action Rail
            Column(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 10.dp, bottom = 64.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                CreatorRailButton(
                    icon = Icons.Default.Favorite,
                    count = "342.1K",
                    tint = TikTokPink
                )
                CreatorRailButton(
                    icon = Icons.Default.ChatBubble,
                    count = "1.8K",
                    tint = Color.White
                )
                CreatorRailButton(
                    icon = Icons.Default.Bookmark,
                    count = "89.4K",
                    tint = ViralYellow
                )
                CreatorRailButton(
                    icon = Icons.Default.Share,
                    count = "24.6K",
                    tint = Color.White
                )

                // Rotating Vinyl Disc
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .rotate(if (isPlaying) discRotation else 0f)
                        .clip(CircleShape)
                        .background(Color(0xFF1E1E24))
                        .border(2.dp, Color(0xFF33333E), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(TikTokPink)
                    )
                }
            }

            // 7. Bottom Creator Metadata (Handle, Title, Hashtags)
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth(0.78f)
                    .padding(start = 14.dp, bottom = 18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "@shortscraft.ai",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = "Verified",
                        tint = TikTokCyan,
                        modifier = Modifier.size(13.dp)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = project.viralTitle.ifBlank { project.title },
                    color = Color.White.copy(alpha = 0.95f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = project.hashtags,
                    color = TikTokCyan.copy(alpha = 0.9f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // 8. Multi-Segment Timeline Progress Bar at the very bottom
            SegmentedProgressBar(
                scenes = scenes,
                currentSceneIndex = currentSceneIndex,
                sceneProgress = sceneProgress,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
private fun SceneVisualBackground(
    theme: String,
    scale: Float,
    translationY: Float,
    transition: String,
    sceneProgress: Float
) {
    val drawableRes = when {
        theme.contains("Space", ignoreCase = true) || theme.contains("Cosmic", ignoreCase = true) -> R.drawable.bg_deep_space
        theme.contains("Ancient", ignoreCase = true) || theme.contains("Mystery", ignoreCase = true) -> R.drawable.bg_ancient_mystery
        else -> R.drawable.bg_cyberpunk_city
    }

    // Flash cut transition effect: brief white flash in the first 8% of scene
    val isFlash = transition == "Flash Cut" && sceneProgress < 0.08f

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = drawableRes),
            contentDescription = "Scene visual background",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    this.translationY = translationY
                }
        )

        // Flash overlay
        if (isFlash) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White.copy(alpha = 0.6f))
            )
        }

        // Glitch line overlay if transition is glitch
        if (transition == "Glitch" && sceneProgress < 0.15f) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .align(Alignment.Center)
                    .background(TikTokCyan.copy(alpha = 0.8f))
            )
        }
    }
}

@Composable
private fun KineticCaptionDisplay(
    captionText: String,
    sceneProgress: Float,
    style: com.example.data.CaptionStyle
) {
    val words = remember(captionText) { captionText.split(" ").filter { it.isNotBlank() } }
    if (words.isEmpty()) return

    // Word highlighting based on scene progress
    val activeWordIndex = (sceneProgress * words.size).toInt().coerceIn(0, words.size - 1)

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(style.backgroundColorHex),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(style.highlightColorHex).copy(alpha = 0.4f)),
        modifier = Modifier.shadow(8.dp, RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            words.forEachIndexed { idx, word ->
                val isActive = idx == activeWordIndex
                val displayWord = if (style.isUppercase) word.uppercase() else word

                Text(
                    text = "$displayWord ",
                    fontSize = if (isActive) (style.fontSizeSp + 2).sp else style.fontSizeSp.sp,
                    fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.Bold,
                    color = if (isActive) Color(style.highlightColorHex) else Color(style.primaryColorHex),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.scale(if (isActive) 1.08f else 1.0f)
                )
            }
        }
    }
}

@Composable
private fun CreatorRailButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    count: String,
    tint: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            shape = CircleShape,
            color = Color.Black.copy(alpha = 0.45f),
            modifier = Modifier.size(40.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = tint,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = count,
            color = Color.White,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun SegmentedProgressBar(
    scenes: List<VideoScene>,
    currentSceneIndex: Int,
    sceneProgress: Float,
    modifier: Modifier = Modifier
) {
    if (scenes.isEmpty()) return

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        scenes.forEachIndexed { idx, scene ->
            val weight = (scene.durationSeconds.toFloat()).coerceAtLeast(1f)
            val segmentFill = when {
                idx < currentSceneIndex -> 1f
                idx == currentSceneIndex -> sceneProgress.coerceIn(0f, 1f)
                else -> 0f
            }

            Box(
                modifier = Modifier
                    .weight(weight)
                    .height(3.5.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.35f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(segmentFill)
                        .background(Color.White)
                )
            }
        }
    }
}
