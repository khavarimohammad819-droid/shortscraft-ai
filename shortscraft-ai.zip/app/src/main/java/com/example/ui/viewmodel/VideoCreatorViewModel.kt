package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiVideoService
import com.example.audio.ShortsAudioEngine
import com.example.data.AppDatabase
import com.example.data.DefaultProjects
import com.example.data.ProjectRepository
import com.example.data.VideoProject
import com.example.data.VideoScene
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class StudioTab(val title: String, val iconName: String) {
    PLAYER("Studio", "play_arrow"),
    TIMELINE("Timeline", "view_timeline"),
    LIBRARY("Library", "video_library"),
    EXPORT("Export", "file_upload")
}

class VideoCreatorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ProjectRepository
    val audioEngine = ShortsAudioEngine(application)
    private val geminiService = GeminiVideoService()

    val allProjects: StateFlow<List<VideoProject>>

    private val _currentProject = MutableStateFlow<VideoProject?>(null)
    val currentProject: StateFlow<VideoProject?> = _currentProject.asStateFlow()

    private val _selectedTab = MutableStateFlow(StudioTab.PLAYER)
    val selectedTab: StateFlow<StudioTab> = _selectedTab.asStateFlow()

    // Playback state
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentSceneIndex = MutableStateFlow(0)
    val currentSceneIndex: StateFlow<Int> = _currentSceneIndex.asStateFlow()

    private val _sceneProgress = MutableStateFlow(0f)
    val sceneProgress: StateFlow<Float> = _sceneProgress.asStateFlow()

    private val _totalProgress = MutableStateFlow(0f)
    val totalProgress: StateFlow<Float> = _totalProgress.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _isMutedVoice = MutableStateFlow(false)
    val isMutedVoice: StateFlow<Boolean> = _isMutedVoice.asStateFlow()

    private val _isMutedMusic = MutableStateFlow(false)
    val isMutedMusic: StateFlow<Boolean> = _isMutedMusic.asStateFlow()

    // AI Generation
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _generationStep = MutableStateFlow("")
    val generationStep: StateFlow<String> = _generationStep.asStateFlow()

    // Export simulation
    private val _isExporting = MutableStateFlow(false)
    val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

    private val _exportProgress = MutableStateFlow(0f)
    val exportProgress: StateFlow<Float> = _exportProgress.asStateFlow()

    private val _exportStatus = MutableStateFlow("")
    val exportStatus: StateFlow<String> = _exportStatus.asStateFlow()

    // Dialog flags
    private val _showAiDialog = MutableStateFlow(false)
    val showAiDialog: StateFlow<Boolean> = _showAiDialog.asStateFlow()

    private val _showSceneEditor = MutableStateFlow(false)
    val showSceneEditor: StateFlow<Boolean> = _showSceneEditor.asStateFlow()

    private val _editingScene = MutableStateFlow<VideoScene?>(null)
    val editingScene: StateFlow<VideoScene?> = _editingScene.asStateFlow()

    private val _showExportDialog = MutableStateFlow(false)
    val showExportDialog: StateFlow<Boolean> = _showExportDialog.asStateFlow()

    private var playbackJob: Job? = null

    init {
        val db = AppDatabase.getDatabase(application)
        repository = ProjectRepository(db.projectDao())
        allProjects = repository.allProjects.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        viewModelScope.launch {
            repository.checkAndSeedDefaults()
            allProjects.collect { projects ->
                if (_currentProject.value == null && projects.isNotEmpty()) {
                    loadProject(projects.first())
                }
            }
        }
    }

    fun selectTab(tab: StudioTab) {
        _selectedTab.value = tab
    }

    fun loadProject(project: VideoProject) {
        pause()
        _currentProject.value = project
        _currentSceneIndex.value = 0
        _sceneProgress.value = 0f
        _totalProgress.value = 0f
    }

    fun togglePlay() {
        if (_isPlaying.value) {
            pause()
        } else {
            play()
        }
    }

    fun play() {
        val proj = _currentProject.value ?: return
        val scenes = proj.getScenes()
        if (scenes.isEmpty()) return

        _isPlaying.value = true
        audioEngine.startMusicLoop(proj.musicTrack)

        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            val speed = _playbackSpeed.value

            while (isActive && _isPlaying.value) {
                val currentIdx = _currentSceneIndex.value
                val scene = scenes.getOrNull(currentIdx) ?: scenes.first()
                val durationMs = (scene.durationSeconds * 1000 / speed).toLong()

                // Trigger voiceover & sound effect
                val persona = DefaultProjects.voicePersonas.find { it.name == proj.voicePersona }
                    ?: DefaultProjects.voicePersonas.first()

                audioEngine.playSoundEffect(scene.soundEffect)
                audioEngine.speakScene(
                    text = scene.voiceoverText,
                    pitch = persona.pitch,
                    speechRate = persona.speechRate * speed
                )

                // Progress loop for this scene
                val stepIntervalMs = 50L
                var elapsed = 0L

                while (elapsed < durationMs && isActive && _isPlaying.value) {
                    delay(stepIntervalMs)
                    elapsed += stepIntervalMs
                    _sceneProgress.value = (elapsed.toFloat() / durationMs).coerceIn(0f, 1f)

                    // Calculate total progress
                    val totalSec = proj.totalDurationSeconds.coerceAtLeast(1)
                    val completedScenesSec = scenes.take(currentIdx).sumOf { it.durationSeconds }
                    val currentSceneElapsedSec = (elapsed.toFloat() / 1000f) * speed
                    _totalProgress.value = ((completedScenesSec + currentSceneElapsedSec) / totalSec).coerceIn(0f, 1f)
                }

                if (!isActive || !_isPlaying.value) break

                // Advance to next scene or loop
                if (currentIdx + 1 < scenes.size) {
                    _currentSceneIndex.value = currentIdx + 1
                    _sceneProgress.value = 0f
                } else {
                    // loop back to first scene
                    _currentSceneIndex.value = 0
                    _sceneProgress.value = 0f
                }
            }
        }
    }

    fun pause() {
        _isPlaying.value = false
        playbackJob?.cancel()
        playbackJob = null
        audioEngine.stopVoice()
        audioEngine.stopMusic()
    }

    fun nextScene() {
        val proj = _currentProject.value ?: return
        val scenes = proj.getScenes()
        if (scenes.isEmpty()) return
        val next = (_currentSceneIndex.value + 1) % scenes.size
        jumpToScene(next)
    }

    fun prevScene() {
        val proj = _currentProject.value ?: return
        val scenes = proj.getScenes()
        if (scenes.isEmpty()) return
        val prev = if (_currentSceneIndex.value - 1 < 0) scenes.size - 1 else _currentSceneIndex.value - 1
        jumpToScene(prev)
    }

    fun jumpToScene(index: Int) {
        val proj = _currentProject.value ?: return
        val scenes = proj.getScenes()
        if (index in scenes.indices) {
            _currentSceneIndex.value = index
            _sceneProgress.value = 0f
            val totalSec = proj.totalDurationSeconds.coerceAtLeast(1)
            val completedSec = scenes.take(index).sumOf { it.durationSeconds }
            _totalProgress.value = (completedSec.toFloat() / totalSec).coerceIn(0f, 1f)

            if (_isPlaying.value) {
                // re-trigger audio for new scene
                val scene = scenes[index]
                val persona = DefaultProjects.voicePersonas.find { it.name == proj.voicePersona }
                    ?: DefaultProjects.voicePersonas.first()
                audioEngine.playSoundEffect(scene.soundEffect)
                audioEngine.speakScene(
                    text = scene.voiceoverText,
                    pitch = persona.pitch,
                    speechRate = persona.speechRate * _playbackSpeed.value
                )
            }
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        if (_isPlaying.value) {
            pause()
            play()
        }
    }

    fun toggleMuteVoice() {
        val newMuted = !_isMutedVoice.value
        _isMutedVoice.value = newMuted
        audioEngine.setMuteVoice(newMuted)
    }

    fun toggleMuteMusic() {
        val newMuted = !_isMutedMusic.value
        _isMutedMusic.value = newMuted
        audioEngine.setMuteMusic(newMuted)
    }

    // AI Generation
    fun openAiDialog() {
        _showAiDialog.value = true
    }

    fun closeAiDialog() {
        _showAiDialog.value = false
    }

    fun generateVideoWithAi(
        topic: String,
        niche: String,
        durationSec: Int = 20,
        voiceStyle: String = "Alex (Hyped Creator)",
        visualStyle: String = "Cyberpunk"
    ) {
        pause()
        _isGenerating.value = true
        _generationStep.value = "Consulting Gemini 3.5 Flash AI..."

        viewModelScope.launch {
            try {
                _generationStep.value = "Crafting high-retention viral hook..."
                delay(400)
                _generationStep.value = "Generating multi-scene storyboard..."

                val script = geminiService.generateShortsScript(
                    topic = topic,
                    niche = niche,
                    targetDurationSec = durationSec,
                    voiceStyle = voiceStyle,
                    visualStyle = visualStyle
                )

                _generationStep.value = "Finalizing captions and sound cues..."
                delay(300)

                val newProject = VideoProject(
                    id = 0,
                    title = script.title,
                    topic = topic,
                    niche = niche,
                    aspectRatio = "9:16",
                    voicePersona = voiceStyle,
                    captionStyle = "MrBeast Pop",
                    musicTrack = if (niche.contains("Tech") || niche.contains("AI")) "Phonk Energy (Viral)" else "Deep Cosmic Synth",
                    scenesJson = VideoProject.scenesToJson(script.scenes),
                    viralHook = script.viralHook,
                    viralTitle = script.viralTitle,
                    hashtags = script.hashtags,
                    totalDurationSeconds = script.scenes.sumOf { it.durationSeconds }
                )

                val newId = repository.saveProject(newProject)
                val saved = newProject.copy(id = newId)
                _currentProject.value = saved
                _showAiDialog.value = false
                _selectedTab.value = StudioTab.PLAYER
                jumpToScene(0)
            } catch (e: Exception) {
                // fallback
            } finally {
                _isGenerating.value = false
                _generationStep.value = ""
            }
        }
    }

    // Scene management
    fun openSceneEditor(scene: VideoScene) {
        _editingScene.value = scene
        _showSceneEditor.value = true
    }

    fun closeSceneEditor() {
        _showSceneEditor.value = false
        _editingScene.value = null
    }

    fun saveEditedScene(updatedScene: VideoScene) {
        val proj = _currentProject.value ?: return
        val currentScenes = proj.getScenes().toMutableList()
        val index = currentScenes.indexOfFirst { it.id == updatedScene.id }
        if (index != -1) {
            currentScenes[index] = updatedScene
        } else {
            currentScenes.add(updatedScene)
        }

        updateProjectScenes(currentScenes)
        closeSceneEditor()
    }

    fun addNewScene() {
        val proj = _currentProject.value ?: return
        val currentScenes = proj.getScenes().toMutableList()
        val nextIndex = currentScenes.size + 1
        val newScene = VideoScene(
            id = "scene_${System.currentTimeMillis().toString().takeLast(6)}",
            sceneIndex = nextIndex,
            visualPrompt = "Cinematic 9:16 vertical shot emphasizing ${proj.topic}",
            visualTheme = currentScenes.lastOrNull()?.visualTheme ?: "Cyberpunk",
            voiceoverText = "Here is an incredible secret you need to know.",
            captionOverlay = "SECRET REVEALED!",
            durationSeconds = 4,
            transition = "Zoom In",
            soundEffect = "Whoosh"
        )
        currentScenes.add(newScene)
        updateProjectScenes(currentScenes)
    }

    fun deleteScene(sceneId: String) {
        val proj = _currentProject.value ?: return
        val currentScenes = proj.getScenes().filter { it.id != sceneId }.toMutableList()
        if (currentScenes.isEmpty()) return
        // reindex
        val reindexed = currentScenes.mapIndexed { idx, s -> s.copy(sceneIndex = idx + 1) }
        updateProjectScenes(reindexed)
        if (_currentSceneIndex.value >= reindexed.size) {
            _currentSceneIndex.value = (reindexed.size - 1).coerceAtLeast(0)
        }
    }

    fun moveScene(fromIndex: Int, toIndex: Int) {
        val proj = _currentProject.value ?: return
        val scenes = proj.getScenes().toMutableList()
        if (fromIndex in scenes.indices && toIndex in scenes.indices && fromIndex != toIndex) {
            val item = scenes.removeAt(fromIndex)
            scenes.add(toIndex, item)
            val reindexed = scenes.mapIndexed { idx, s -> s.copy(sceneIndex = idx + 1) }
            updateProjectScenes(reindexed)
        }
    }

    private fun updateProjectScenes(newScenes: List<VideoScene>) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(
            scenesJson = VideoProject.scenesToJson(newScenes),
            totalDurationSeconds = newScenes.sumOf { it.durationSeconds }
        )
        _currentProject.value = updated
        viewModelScope.launch {
            repository.saveProject(updated)
        }
    }

    fun updateCaptionStyle(styleName: String) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(captionStyle = styleName)
        _currentProject.value = updated
        viewModelScope.launch { repository.saveProject(updated) }
    }

    fun updateVoicePersona(personaName: String) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(voicePersona = personaName)
        _currentProject.value = updated
        viewModelScope.launch { repository.saveProject(updated) }
    }

    fun updateMusicTrack(trackName: String) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(musicTrack = trackName)
        _currentProject.value = updated
        if (_isPlaying.value) {
            audioEngine.startMusicLoop(trackName)
        }
        viewModelScope.launch { repository.saveProject(updated) }
    }

    fun updateProjectTitle(newTitle: String) {
        val proj = _currentProject.value ?: return
        val updated = proj.copy(title = newTitle)
        _currentProject.value = updated
        viewModelScope.launch { repository.saveProject(updated) }
    }

    fun deleteProject(id: Long) {
        viewModelScope.launch {
            repository.deleteProject(id)
        }
    }

    // Export Flow
    fun openExportDialog() {
        pause()
        _showExportDialog.value = true
        _exportProgress.value = 0f
        _isExporting.value = false
    }

    fun closeExportDialog() {
        _showExportDialog.value = false
    }

    fun startExportSimulation() {
        _isExporting.value = true
        _exportProgress.value = 0f

        viewModelScope.launch {
            val stages = listOf(
                "Synthesizing voiceover track..." to 0.25f,
                "Rendering 9:16 vertical visual scenes..." to 0.55f,
                "Baking kinetic subtitle animations..." to 0.80f,
                "Mastering audio & exporting MP4..." to 1.0f
            )

            for ((status, targetProgress) in stages) {
                _exportStatus.value = status
                val start = _exportProgress.value
                val steps = 10
                for (i in 1..steps) {
                    delay(80)
                    _exportProgress.value = start + (targetProgress - start) * (i.toFloat() / steps)
                }
            }

            _exportStatus.value = "Video Render Complete!"
            _isExporting.value = false
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.release()
    }
}
