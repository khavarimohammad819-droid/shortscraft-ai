package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.VolumeMute
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.ViewTimeline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AiGeneratorSheet
import com.example.ui.components.ExportStudioDialog
import com.example.ui.components.ProjectLibraryScreen
import com.example.ui.components.SceneEditorDialog
import com.example.ui.components.SceneTimelineEditor
import com.example.ui.components.ShortsVideoPlayer
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TikTokCyan
import com.example.ui.theme.TikTokPink
import com.example.ui.theme.ViralYellow
import com.example.ui.viewmodel.StudioTab
import com.example.ui.viewmodel.VideoCreatorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainStudioScreen(
    viewModel: VideoCreatorViewModel = viewModel()
) {
    val currentProject by viewModel.currentProject.collectAsState()
    val allProjects by viewModel.allProjects.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()

    // Playback state
    val isPlaying by viewModel.isPlaying.collectAsState()
    val currentSceneIndex by viewModel.currentSceneIndex.collectAsState()
    val sceneProgress by viewModel.sceneProgress.collectAsState()
    val playbackSpeed by viewModel.playbackSpeed.collectAsState()
    val isMutedVoice by viewModel.isMutedVoice.collectAsState()
    val isMutedMusic by viewModel.isMutedMusic.collectAsState()

    // AI Generation state
    val isGenerating by viewModel.isGenerating.collectAsState()
    val generationStep by viewModel.generationStep.collectAsState()
    val showAiDialog by viewModel.showAiDialog.collectAsState()

    // Editor & Export
    val showSceneEditor by viewModel.showSceneEditor.collectAsState()
    val editingScene by viewModel.editingScene.collectAsState()
    val showExportDialog by viewModel.showExportDialog.collectAsState()
    val isExporting by viewModel.isExporting.collectAsState()
    val exportProgress by viewModel.exportProgress.collectAsState()
    val exportStatus by viewModel.exportStatus.collectAsState()

    Scaffold(
        containerColor = DarkBackground,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(
                                    Brush.linearGradient(listOf(TikTokPink, ElectricViolet)),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "ShortsCraft",
                                    color = TextPrimary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "AI",
                                    color = TikTokPink,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Text(
                                text = currentProject?.viralTitle ?: "TikTok & Shorts Creator",
                                color = TextMuted,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.widthIn(max = 160.dp)
                            )
                        }
                    }
                },
                actions = {
                    // AI Quick Generate button
                    Button(
                        onClick = { viewModel.openAiDialog() },
                        colors = ButtonDefaults.buttonColors(containerColor = TikTokPink),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("top_ai_create_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "AI",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Audio Mute toggle
                    IconButton(
                        onClick = {
                            viewModel.toggleMuteVoice()
                            viewModel.toggleMuteMusic()
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = if (isMutedVoice && isMutedMusic) Icons.AutoMirrored.Filled.VolumeMute else Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Mute Audio",
                            tint = if (isMutedVoice && isMutedMusic) TextMuted else TikTokCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Export button
                    IconButton(
                        onClick = { viewModel.openExportDialog() },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileUpload,
                            contentDescription = "Export Video",
                            tint = TextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                modifier = Modifier
                    .border(
                        width = 1.dp,
                        color = StudioBorder,
                        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                    )
                    .testTag("main_navigation_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == StudioTab.PLAYER,
                    onClick = { viewModel.selectTab(StudioTab.PLAYER) },
                    icon = { Icon(Icons.Default.PlayArrow, contentDescription = "Studio") },
                    label = { Text("Studio", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = TikTokPink,
                        selectedTextColor = TikTokPink,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary,
                        indicatorColor = TikTokPink.copy(alpha = 0.15f)
                    )
                )

                NavigationBarItem(
                    selected = selectedTab == StudioTab.TIMELINE,
                    onClick = { viewModel.selectTab(StudioTab.TIMELINE) },
                    icon = { Icon(Icons.Default.ViewTimeline, contentDescription = "Timeline") },
                    label = { Text("Timeline", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = TikTokCyan,
                        selectedTextColor = TikTokCyan,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary,
                        indicatorColor = TikTokCyan.copy(alpha = 0.15f)
                    )
                )

                NavigationBarItem(
                    selected = selectedTab == StudioTab.LIBRARY,
                    onClick = { viewModel.selectTab(StudioTab.LIBRARY) },
                    icon = { Icon(Icons.Default.VideoLibrary, contentDescription = "Library") },
                    label = { Text("Library", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ViralYellow,
                        selectedTextColor = ViralYellow,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary,
                        indicatorColor = ViralYellow.copy(alpha = 0.15f)
                    )
                )

                NavigationBarItem(
                    selected = false,
                    onClick = { viewModel.openExportDialog() },
                    icon = { Icon(Icons.Default.FileUpload, contentDescription = "Export") },
                    label = { Text("Export", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = TextPrimary,
                        selectedTextColor = TextPrimary,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            val proj = currentProject

            if (proj == null) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = TikTokPink)
                }
            } else {
                when (selectedTab) {
                    StudioTab.PLAYER -> {
                        StudioPlayerTabContent(
                            project = proj,
                            currentSceneIndex = currentSceneIndex,
                            sceneProgress = sceneProgress,
                            isPlaying = isPlaying,
                            playbackSpeed = playbackSpeed,
                            onTogglePlay = { viewModel.togglePlay() },
                            onNextScene = { viewModel.nextScene() },
                            onPrevScene = { viewModel.prevScene() },
                            onOpenTimeline = { viewModel.selectTab(StudioTab.TIMELINE) },
                            onOpenEditor = {
                                val currentScene = proj.getScenes().getOrNull(currentSceneIndex)
                                if (currentScene != null) {
                                    viewModel.openSceneEditor(currentScene)
                                }
                            },
                            onOpenAi = { viewModel.openAiDialog() }
                        )
                    }

                    StudioTab.TIMELINE -> {
                        SceneTimelineEditor(
                            project = proj,
                            currentSceneIndex = currentSceneIndex,
                            isPlaying = isPlaying,
                            playbackSpeed = playbackSpeed,
                            isMutedVoice = isMutedVoice,
                            isMutedMusic = isMutedMusic,
                            onTogglePlay = { viewModel.togglePlay() },
                            onNextScene = { viewModel.nextScene() },
                            onPrevScene = { viewModel.prevScene() },
                            onJumpToScene = { viewModel.jumpToScene(it) },
                            onSetSpeed = { viewModel.setPlaybackSpeed(it) },
                            onToggleMuteVoice = { viewModel.toggleMuteVoice() },
                            onToggleMuteMusic = { viewModel.toggleMuteMusic() },
                            onOpenSceneEditor = { viewModel.openSceneEditor(it) },
                            onAddNewScene = { viewModel.addNewScene() },
                            onDeleteScene = { viewModel.deleteScene(it) },
                            onMoveScene = { from, to -> viewModel.moveScene(from, to) },
                            onUpdateCaptionStyle = { viewModel.updateCaptionStyle(it) },
                            onUpdateVoicePersona = { viewModel.updateVoicePersona(it) },
                            onUpdateMusicTrack = { viewModel.updateMusicTrack(it) }
                        )
                    }

                    StudioTab.LIBRARY -> {
                        ProjectLibraryScreen(
                            projects = allProjects,
                            currentProjectId = proj.id,
                            onSelectProject = {
                                viewModel.loadProject(it)
                                viewModel.selectTab(StudioTab.PLAYER)
                            },
                            onDeleteProject = { viewModel.deleteProject(it) },
                            onOpenAiGenerator = { viewModel.openAiDialog() },
                            onOpenExport = {
                                viewModel.loadProject(it)
                                viewModel.openExportDialog()
                            }
                        )
                    }

                    StudioTab.EXPORT -> {
                        // handled via dialog
                    }
                }
            }
        }
    }

    // AI Generator Sheet
    if (showAiDialog) {
        AiGeneratorSheet(
            isGenerating = isGenerating,
            generationStep = generationStep,
            onDismiss = { viewModel.closeAiDialog() },
            onGenerate = { topic, niche, dur, voice, vis ->
                viewModel.generateVideoWithAi(topic, niche, dur, voice, vis)
            }
        )
    }

    // Scene Editor Dialog
    if (showSceneEditor && editingScene != null) {
        SceneEditorDialog(
            scene = editingScene!!,
            onDismiss = { viewModel.closeSceneEditor() },
            onSave = { viewModel.saveEditedScene(it) }
        )
    }

    // Export Studio Dialog
    if (showExportDialog && currentProject != null) {
        ExportStudioDialog(
            project = currentProject!!,
            isExporting = isExporting,
            exportProgress = exportProgress,
            exportStatus = exportStatus,
            onStartExport = { viewModel.startExportSimulation() },
            onDismiss = { viewModel.closeExportDialog() }
        )
    }
}

@Composable
private fun StudioPlayerTabContent(
    project: com.example.data.VideoProject,
    currentSceneIndex: Int,
    sceneProgress: Float,
    isPlaying: Boolean,
    playbackSpeed: Float,
    onTogglePlay: () -> Unit,
    onNextScene: () -> Unit,
    onPrevScene: () -> Unit,
    onOpenTimeline: () -> Unit,
    onOpenEditor: () -> Unit,
    onOpenAi: () -> Unit
) {
    val scenes = project.getScenes()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 1. Interactive 9:16 Shorts Video Viewport
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            ShortsVideoPlayer(
                project = project,
                currentSceneIndex = currentSceneIndex,
                sceneProgress = sceneProgress,
                isPlaying = isPlaying,
                onTogglePlay = onTogglePlay,
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 2. Control Bar below player
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = StudioCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Scene badge & Previous
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onPrevScene, modifier = Modifier.size(34.dp)) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Prev",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DarkSurfaceVariant
                    ) {
                        Text(
                            text = "${currentSceneIndex + 1}/${scenes.size}",
                            color = TikTokCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }

                    IconButton(onClick = onNextScene, modifier = Modifier.size(34.dp)) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Next",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Center Play/Pause button
                Surface(
                    shape = CircleShape,
                    color = if (isPlaying) TikTokPink else TikTokCyan,
                    modifier = Modifier
                        .size(42.dp)
                        .clickable(onClick = onTogglePlay)
                        .testTag("player_center_play_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.Black,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // Edit scene & Timeline shortcuts
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onOpenEditor, modifier = Modifier.size(34.dp)) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Scene",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(onClick = onOpenTimeline, modifier = Modifier.size(34.dp)) {
                        Icon(
                            imageVector = Icons.Default.ViewTimeline,
                            contentDescription = "Timeline",
                            tint = TikTokCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
    }
}
