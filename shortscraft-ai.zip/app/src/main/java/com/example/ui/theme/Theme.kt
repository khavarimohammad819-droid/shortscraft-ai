package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val StudioColorScheme = darkColorScheme(
  primary = TikTokPink,
  onPrimary = Color.White,
  primaryContainer = Color(0xFF4A1020),
  onPrimaryContainer = Color(0xFFFFDADE),
  secondary = TikTokCyan,
  onSecondary = Color(0xFF00363A),
  secondaryContainer = Color(0xFF004F54),
  onSecondaryContainer = Color(0xFF6FF7F5),
  tertiary = ViralYellow,
  onTertiary = Color(0xFF3B2F00),
  tertiaryContainer = Color(0xFF564500),
  onTertiaryContainer = Color(0xFFFFE171),
  background = StudioDark,
  onBackground = TextPrimary,
  surface = StudioCard,
  onSurface = TextPrimary,
  surfaceVariant = StudioCardHover,
  onSurfaceVariant = TextSecondary,
  outline = StudioBorder,
  outlineVariant = Color(0xFF1E2030)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = StudioColorScheme,
    typography = Typography,
    content = content
  )
}

