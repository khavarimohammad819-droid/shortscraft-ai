package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StudioDark = Color(0xFF0C0D14)
val DarkBackground = StudioDark
val StudioCard = Color(0xFF161724)
val StudioCardHover = Color(0xFF202234)
val StudioBorder = Color(0xFF282A40)

val TikTokPink = Color(0xFFFE2C55)
val TikTokCyan = Color(0xFF25F4EE)
val ElectricViolet = Color(0xFF8B5CF6)
val ViralYellow = Color(0xFFFFD600)
val ViralGreen = Color(0xFF00E676)
val StudioAmber = Color(0xFFFF9100)

val DarkSurface = Color(0xFF12131C)
val DarkSurfaceVariant = Color(0xFF1E2030)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val Purple80 = ElectricViolet
val PurpleGrey80 = Color(0xFFB0B7C3)
val Pink80 = TikTokPink

val Purple40 = Color(0xFF6D28D9)
val PurpleGrey40 = Color(0xFF475569)
val Pink40 = Color(0xFFBE185D)

