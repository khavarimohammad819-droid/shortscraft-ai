package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.VideoScene
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TikTokCyan
import com.example.ui.theme.TikTokPink
import com.example.ui.theme.ViralYellow

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SceneEditorDialog(
    scene: VideoScene,
    onDismiss: () -> Unit,
    onSave: (VideoScene) -> Unit
) {
    var voiceoverText by remember { mutableStateOf(scene.voiceoverText) }
    var captionOverlay by remember { mutableStateOf(scene.captionOverlay) }
    var visualPrompt by remember { mutableStateOf(scene.visualPrompt) }
    var visualTheme by remember { mutableStateOf(scene.visualTheme) }
    var durationSec by remember { mutableFloatStateOf(scene.durationSeconds.toFloat()) }
    var transition by remember { mutableStateOf(scene.transition) }
    var soundEffect by remember { mutableStateOf(scene.soundEffect) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("scene_editor_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            tint = TikTokCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Edit Scene #${scene.sceneIndex}",
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 1. Voiceover Narration
                Text(
                    text = "Narration Script (What Voice Says)",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = voiceoverText,
                    onValueChange = { voiceoverText = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TikTokCyan,
                        unfocusedBorderColor = StudioBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = StudioCard,
                        unfocusedContainerColor = StudioCard
                    ),
                    maxLines = 3
                )

                Spacer(modifier = Modifier.height(12.dp))

                // 2. Kinetic Caption Overlay (Uppercase short punch)
                Text(
                    text = "Kinetic Subtitle Words (Flash On Screen)",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = captionOverlay,
                    onValueChange = { captionOverlay = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ViralYellow,
                        unfocusedBorderColor = StudioBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = StudioCard,
                        unfocusedContainerColor = StudioCard
                    ),
                    placeholder = { Text("e.g. STOP SCROLLING!", color = TextMuted) },
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // 3. Visual Prompt
                Text(
                    text = "AI Visual Scene Prompt (Veo / Midjourney)",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = visualPrompt,
                    onValueChange = { visualPrompt = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TikTokPink,
                        unfocusedBorderColor = StudioBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = StudioCard,
                        unfocusedContainerColor = StudioCard
                    ),
                    maxLines = 3
                )

                Spacer(modifier = Modifier.height(12.dp))

                // 4. Visual Theme
                Text(
                    text = "Background Visual Preset",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Cyberpunk", "Deep Space", "Ancient Mystery").forEach { thm ->
                        val isSel = visualTheme == thm
                        FilterChip(
                            selected = isSel,
                            onClick = { visualTheme = thm },
                            label = { Text(thm, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TikTokPink.copy(alpha = 0.2f),
                                selectedLabelColor = TikTokPink
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 5. Duration Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Scene Duration",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${durationSec.toInt()} seconds",
                        color = TikTokCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Slider(
                    value = durationSec,
                    onValueChange = { durationSec = it },
                    valueRange = 2f..10f,
                    steps = 7,
                    colors = SliderDefaults.colors(
                        thumbColor = TikTokCyan,
                        activeTrackColor = TikTokCyan,
                        inactiveTrackColor = DarkSurfaceVariant
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // 6. Transition & Sound Cue
                Text(
                    text = "Transition & Sound FX",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Flash Cut", "Zoom In", "Slide Left", "Glitch", "Fade").forEach { tr ->
                        val isSel = transition == tr
                        FilterChip(
                            selected = isSel,
                            onClick = { transition = tr },
                            label = { Text("⚡ $tr", fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TikTokCyan.copy(alpha = 0.2f),
                                selectedLabelColor = TikTokCyan
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Sub Drop", "Whoosh", "Ding", "Camera Click", "Pop", "None").forEach { sfx ->
                        val isSel = soundEffect == sfx
                        FilterChip(
                            selected = isSel,
                            onClick = { soundEffect = sfx },
                            label = { Text("🔊 $sfx", fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TikTokPink.copy(alpha = 0.2f),
                                selectedLabelColor = TikTokPink
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Save button
                Button(
                    onClick = {
                        val updated = scene.copy(
                            voiceoverText = voiceoverText,
                            captionOverlay = captionOverlay,
                            visualPrompt = visualPrompt,
                            visualTheme = visualTheme,
                            durationSeconds = durationSec.toInt().coerceIn(2, 12),
                            transition = transition,
                            soundEffect = soundEffect
                        )
                        onSave(updated)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TikTokCyan, contentColor = Color.Black)
                ) {
                    Icon(imageVector = Icons.Default.Done, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("SAVE SCENE CHANGES", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}
