package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.PI
import kotlin.math.sin

class ShortsAudioEngine(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var isTtsMuted = false
    private var isMusicMuted = false
    private var musicJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("ShortsAudioEngine", "Failed to init TTS", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.let { engine ->
                val result = engine.setLanguage(Locale.US)
                if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                    isTtsReady = true
                }
            }
        }
    }

    fun configureVoice(pitch: Float, speechRate: Float) {
        if (!isTtsReady) return
        tts?.setPitch(pitch)
        tts?.setSpeechRate(speechRate)
    }

    fun speakScene(text: String, pitch: Float = 1.0f, speechRate: Float = 1.2f) {
        if (!isTtsReady || isTtsMuted || text.isBlank()) return
        configureVoice(pitch, speechRate)
        tts?.stop()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "scene_voice")
    }

    fun stopVoice() {
        tts?.stop()
    }

    fun setMuteVoice(muted: Boolean) {
        isTtsMuted = muted
        if (muted) stopVoice()
    }

    fun setMuteMusic(muted: Boolean) {
        isMusicMuted = muted
        if (muted) stopMusic()
    }

    fun playSoundEffect(effectName: String) {
        scope.launch(Dispatchers.IO) {
            try {
                when (effectName) {
                    "Sub Drop" -> generateSubDropSound()
                    "Whoosh" -> generateWhooshSound()
                    "Ding" -> generateTone(880.0, 0.25, 0.6)
                    "Camera Click" -> generateClickSound()
                    "Pop" -> generateTone(600.0, 0.08, 0.7)
                    else -> {}
                }
            } catch (e: Exception) {
                // Ignore audio track glitches
            }
        }
    }

    fun startMusicLoop(trackName: String) {
        stopMusic()
        if (isMusicMuted || trackName == "None" || trackName.contains("No Music")) return

        musicJob = scope.launch(Dispatchers.IO) {
            val sampleRate = 22050
            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minBuf.coerceAtLeast(4096))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack.play()

            try {
                var step = 0
                val bassNotes = when {
                    trackName.contains("Phonk") -> doubleArrayOf(55.0, 55.0, 65.4, 49.0) // A1, C2, G1
                    trackName.contains("Cosmic") -> doubleArrayOf(65.4, 73.4, 82.4, 58.2) // C2, D2, E2, Bb1
                    trackName.contains("Lo-Fi") -> doubleArrayOf(65.4, 87.3, 77.8, 58.2) // C2, F2, Eb2
                    else -> doubleArrayOf(55.0, 65.4, 73.4, 49.0)
                }

                while (isActive && !isMusicMuted) {
                    val freq = bassNotes[step % bassNotes.size]
                    val durationMs = 400
                    val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
                    val buffer = ShortArray(numSamples)

                    for (i in 0 until numSamples) {
                        val t = i.toDouble() / sampleRate
                        val env = (1.0 - (i.toDouble() / numSamples)).coerceIn(0.0, 1.0)
                        val sample = sin(2 * PI * freq * t) * 0.3 * env +
                                sin(2 * PI * (freq * 2) * t) * 0.15 * env
                        buffer[i] = (sample * 16000).toInt().coerceIn(-32767, 32767).toShort()
                    }

                    audioTrack.write(buffer, 0, buffer.size)
                    step++
                    delay(30)
                }
            } catch (e: Exception) {
                // finished
            } finally {
                try {
                    audioTrack.stop()
                    audioTrack.release()
                } catch (e: Exception) {
                    // ignore
                }
            }
        }
    }

    fun stopMusic() {
        musicJob?.cancel()
        musicJob = null
    }

    private fun generateTone(frequency: Double, durationSec: Double, volume: Double) {
        val sampleRate = 22050
        val numSamples = (sampleRate * durationSec).toInt()
        val buffer = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val envelope = (1.0 - (i.toDouble() / numSamples)).coerceIn(0.0, 1.0)
            val sample = sin(2.0 * PI * frequency * t) * volume * envelope
            buffer[i] = (sample * 32767).toInt().coerceIn(-32768, 32767).toShort()
        }

        playRawPcm(buffer, sampleRate)
    }

    private fun generateSubDropSound() {
        val sampleRate = 22050
        val durationSec = 0.5
        val numSamples = (sampleRate * durationSec).toInt()
        val buffer = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            val progress = i.toDouble() / numSamples
            val freq = 140.0 * (1.0 - progress * 0.7) // slide down to ~40Hz
            val envelope = (1.0 - progress)
            val sample = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)) * 0.8 * envelope
            buffer[i] = (sample * 32767).toInt().coerceIn(-32768, 32767).toShort()
        }

        playRawPcm(buffer, sampleRate)
    }

    private fun generateWhooshSound() {
        val sampleRate = 22050
        val durationSec = 0.35
        val numSamples = (sampleRate * durationSec).toInt()
        val buffer = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            val progress = i.toDouble() / numSamples
            val envelope = sin(progress * PI)
            val noise = (Math.random() * 2.0 - 1.0)
            val sample = noise * 0.5 * envelope
            buffer[i] = (sample * 32767).toInt().coerceIn(-32768, 32767).toShort()
        }

        playRawPcm(buffer, sampleRate)
    }

    private fun generateClickSound() {
        val sampleRate = 22050
        val numSamples = (sampleRate * 0.05).toInt()
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val noise = (Math.random() * 2.0 - 1.0) * (1.0 - i.toDouble() / numSamples)
            buffer[i] = (noise * 24000).toInt().toShort()
        }
        playRawPcm(buffer, sampleRate)
    }

    private fun playRawPcm(buffer: ShortArray, sampleRate: Int) {
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(buffer.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        track.write(buffer, 0, buffer.size)
        track.play()
        track.setNotificationMarkerPosition(buffer.size)
        track.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
            override fun onPeriodicNotification(track: AudioTrack?) {}
            override fun onMarkerReached(t: AudioTrack?) {
                try {
                    t?.stop()
                    t?.release()
                } catch (e: Exception) {
                    // ignore
                }
            }
        })
    }

    fun release() {
        stopMusic()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
